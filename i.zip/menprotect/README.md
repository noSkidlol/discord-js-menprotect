# menprotect

menprotect - a Lua 5.1 vm obfuscator made in node.js
 - made by Singularity.
